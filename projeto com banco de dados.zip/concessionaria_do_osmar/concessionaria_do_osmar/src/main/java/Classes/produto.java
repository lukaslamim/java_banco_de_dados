
package Classes;

/**
 *
 * @author lucaslamim-fit
 */
public class produto {
    
    private int id = 0;
    private String valor = "";
    private String nome = "";
    private int quantidade = 0;
    private String descrição = "";

    public produto(int id, String valor,String nome, int quantidade, String descrição)
    {
        this.id = id;
        this.valor = valor;
        this.nome = nome;
        this.quantidade = quantidade;
        this.descrição = descrição; 
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @return the descrição
     */
    public String getDescrição() {
        return descrição;
    }
}
