/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author lucaslamim-fit
 */
public class cliente extends pessoa {

    private String celular = "";
    private String email = "";
    
    public cliente(int id, String cpf, String nome, String nascimento, String endereço, boolean sexoMasculino, String cnh, String celular, String email)
    {
        super(id, cpf, nome, nascimento, endereço, sexoMasculino, cnh);
        this.celular = celular;
        this.email = email;
    }  

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the nascimento
     */
    public String getNascimento() {
        return nascimento;
    }

    /**
     * @return the endereço
     */
    public String getEndereço() {
        return endereço;
    }

    /**
     * @return the sexoMasculino
     */
    public boolean isSexoMasculino() {
        return sexoMasculino;
    }

    /**
     * @return the cnh
     */
    public String getCnh() {
        return cnh;
    }

    /**
     * @return the celular
     */
    public String getCelular() {
        return celular;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }
}
