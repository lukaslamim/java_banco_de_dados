
package Classes;
/**
 *
 * @author lucaslamim-fit
 */
public class servico {
    
    private int id = 0;
    private String valor = "";
    private String nome = "";
    private String descrição = "";
    private String tempoMedio = "";       

    public servico(int id, String valor,String nome, String descrição, String tempoMedio) 
    {
        this.id = id;
        this.valor = valor;
        this.nome = nome;
        this.descrição = descrição;
        this.tempoMedio = tempoMedio;      
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the descrição
     */
    public String getDescrição() {
        return descrição;
    }

    /**
     * @return the tempoMedio
     */
    public String getTempoMedio() {
        return tempoMedio;
    }     
}
