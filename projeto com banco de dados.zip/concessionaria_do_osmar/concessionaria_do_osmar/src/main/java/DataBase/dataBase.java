/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBase;

import java.util.ArrayList;
import java.util.List;
import Classes.carro;
import Classes.moto;
import Classes.cliente;
import Classes.funcionario;
import Classes.produto;
import Classes.servico;
import Classes.compra;
/**
 *
 * @author lucaslamim-fit
 */
public class dataBase {
    
    private int id_carro = 1;
    private int id_moto = 1;
    private int id_cliente = 1;
    private int id_funcionario = 1;
    private int id_produto = 1;
    private int id_servico = 1;
    private int id_compra = 1;
    
    private List<carro> carroList = new ArrayList<>();
    private List<moto> motoList = new ArrayList<>();
    private List<cliente> clienteList = new ArrayList<>();
    private List<funcionario> funcionarioList = new ArrayList<>();
    private List<produto> produtoList = new ArrayList<>();
    private List<servico> servicoList = new ArrayList<>();
    private List<compra> compraList = new ArrayList<>();
    
    public void inserir_carro(carro Carro) 
    {
        getCarroList().add(Carro);
        id_carro++;
    }
     
    public void inserir_moto(moto Moto) 
    {
        getMotoList().add(Moto);
        id_moto++;
    }
          
    public void inserir_cliente(cliente Cliente) 
    {
        getClienteList().add(Cliente);
        id_cliente++;
    }

    public void inserir_funcionario(funcionario Funcionario) 
    {
        getFuncionarioList().add(Funcionario);
        id_funcionario++;
    }

    public void inserir_produto(produto Produto) 
    {
        getProdutoList().add(Produto);
        id_produto++;
    }

    public void inserir_servico(servico Servico) 
    {
        getServicoList().add(Servico);
        id_servico++;
    }

    public void inserir_compra(compra Compra) 
    {
        getCompraList().add(Compra);
        id_compra++;
    }
//#######remover#######
    public void remover_carro(int id) 
    {
        if (!getCarroList().isEmpty()) 
        {
            for (int i = 0; i < getCarroList().size(); i++) 
            {
                if (getCarroList().get(i).getId() == id) 
                {
                    getCarroList().remove(i);
                }
            }
        } 
   }

    public void remover_moto(int id) 
    {
        if (!getMotoList().isEmpty()) 
        {
            for (int i = 0; i < getMotoList().size(); i++) 
            {
                if (getMotoList().get(i).getId() == id) 
                {
                    getMotoList().remove(i);
                }
            }
        }  
    }

    public void remover_cliente(int id) 
    {
        if (!getClienteList().isEmpty()) 
        {
            for (int i = 0; i < getClienteList().size(); i++) 
            {
                if (getClienteList().get(i).getId() == id) 
                {
                    getClienteList().remove(i);
                }
            }
        }    
    }

    public void remover_funcionario(int id) 
    {
        if (!getFuncionarioList().isEmpty()) 
        {
            for (int i = 0; i < getFuncionarioList().size(); i++) 
            {
                if (getFuncionarioList().get(i).getId() == id) 
                {
                    getFuncionarioList().remove(i);
                }
            }
        } 
    }

    public void remover_produto(int id) 
    {
        if (!getProdutoList().isEmpty()) 
        {
            for (int i = 0; i < getProdutoList().size(); i++) 
            {
                if (getProdutoList().get(i).getId() == id) 
                {
                    getProdutoList().remove(i);
                }
            }
        }  
    }

    public void remover_servico(int id) 
    {
        if (!getServicoList().isEmpty()) 
        {
            for (int i = 0; i < getServicoList().size(); i++) 
            {
                if (getServicoList().get(i).getId() == id) 
                {
                    getServicoList().remove(i);
                }
            }
        }  
    }
    
    public void remover_compra(int id) 
    {
        if (!getCompraList().isEmpty()) 
        {
            for (int i = 0; i < getCompraList().size(); i++) 
            {
                if (getCompraList().get(i).getId() == id) 
                {
                    getCompraList().remove(i);
                }
            }
        }    
    }
    //int id, String marca, String placa, String cor, String chassi,
    //String modelo, boolean quatroPortas, boolean arCondicionado, String descricao
    public void alimenta_banco()
    {
        moto MOTO1 = new moto(1,"thunder","placa", "azul", "835832", "ferrari", "2021", "4353");
        moto MOTO2 = new moto(2,"honda","placa2", "azul", "383673", "bmw", "2022", "2567");
        moto MOTO3 = new moto(3,"titan","placa3", "azul", "4839683", "fusca9", "2022", "0");
        
        carro CARRO1 = new carro(1,"thunder","placa", "azul", "835832", "AZ", "2021", "2000", true, true, "descricao1");
        carro CARRO2 = new carro(2,"honda","placa2", "azul", "383673", "HT2", "2022", "500", false, true, "descricao1");
        carro CARRO3 = new carro(3,"titan","placa3", "azul", "4839683", "AIAI", "2022", "0", true, false, "descricao1");
        
        produto PRODUTO1 = new produto(1,"10,00","shampo", 10, "limpa sujeiras");
        produto PRODUTO2 = new produto(2,"15,00","condicionador", 2, "deixa o pêlo brilhoso");
        produto PRODUTO3 = new produto(3,"1,00","talco", 5, "disfarça odor");
                
        cliente CLIENTE1 = new cliente(1, "84564547878", "joao", "15/05/2001", "esquina", false, "4836964", "58977112254", "joao@hotmail.com");
        cliente CLIENTE2 = new cliente(2, "54886734876", "marcos", "10/05/2001", "esquina1", true, "4332985", "8590385328", "marcos@hotmail.com");
        cliente CLIENTE3 = new cliente(3, "8932958353i", "carlos", "05/05/2001", "esquina2", true, "3858327", "75389275273", "carlos@hotmail.com");
        
        funcionario FUNCINARIO1 = new funcionario(1, "47325783298", "lukas", "15/02/2001", "esquina1", false, "9476743", "vendedor", 1300.0, false); 
        funcionario FUNCINARIO2 = new funcionario(2, "93857358348", "wiberti", "15/03/2001", "esquina2", true, "5986934", "vendedor",1300.0, true);        
        funcionario FUNCINARIO3 = new funcionario(3, "38758347534", "alex", "15/04/2001", "esquina3", false, "37573758", "gerente", 11300.0, true);   

        servico SERVICO1 = new servico(1,"100,00","raspar", "raspar tudo", "5 minutos");
        servico SERVICO2 = new servico(2,"30,00","banho", "banho completo", "15 minuto");
        servico SERVICO3 = new servico(3,"5,00","olhadinha", "ver", "3 minutos");
        
        inserir_carro(CARRO1);
        inserir_carro(CARRO2);
        inserir_carro(CARRO3);

        inserir_moto(MOTO1);
        inserir_moto(MOTO2);
        inserir_moto(MOTO3);        
      
        inserir_produto(PRODUTO1);
        inserir_produto(PRODUTO2);
        inserir_produto(PRODUTO3);
             
        inserir_cliente(CLIENTE1);
        inserir_cliente(CLIENTE2);
        inserir_cliente(CLIENTE3);
          
        inserir_funcionario(FUNCINARIO1);
        inserir_funcionario(FUNCINARIO2);
        inserir_funcionario(FUNCINARIO3);
        
        inserir_servico(SERVICO1);
        inserir_servico(SERVICO2);
        inserir_servico(SERVICO3);
        
        
    }
    /**
     * @return the carroList
     */
    public List<carro> getCarroList() {
        return carroList;
    }

    /**
     * @return the motoList
     */
    public List<moto> getMotoList() {
        return motoList;
    }

    /**
     * @return the clienteList
     */
    public List<cliente> getClienteList() {
        return clienteList;
    }

    /**
     * @return the funcionarioList
     */
    public List<funcionario> getFuncionarioList() {
        return funcionarioList;
    }

    /**
     * @return the produtoList
     */
    public List<produto> getProdutoList() {
        return produtoList;
    }

    /**
     * @return the servicoList
     */
    public List<servico> getServicoList() {
        return servicoList;
    }

    /**
     * @return the compraList
     */
    public List<compra> getCompraList() {
        return compraList;
    }

    /**
     * @return the id_carro
     */
    public int getId_carro() {
        return id_carro;
    }

    /**
     * @return the id_moto
     */
    public int getId_moto() {
        return id_moto;
    }

    /**
     * @return the id_cliente
     */
    public int getId_cliente() {
        return id_cliente;
    }

    /**
     * @return the id_funcionario
     */
    public int getId_funcionario() {
        return id_funcionario;
    }

    /**
     * @return the id_produto
     */
    public int getId_produto() {
        return id_produto;
    }

    /**
     * @return the id_servico
     */
    public int getId_servico() {
        return id_servico;
    
    }
    /**
     * @return the id_compra
     */
    public int getId_compra() {
        return id_compra;
    }

}


