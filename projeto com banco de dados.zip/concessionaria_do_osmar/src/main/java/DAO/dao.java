package DAO;

import DataBase.dataBase;
import DataBase.conectionDB;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import Classes.carro;
import Classes.moto;
import Classes.cliente;
import Classes.funcionario;
import Classes.produto;
import Classes.servico;
import Classes.compra;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class dao {

    private Connection conect = conectionDB.FazerConeccao();
    private String query = "";
    private PreparedStatement pst = null;
    private Statement st = null;
    private ResultSet rs = null;

    private cliente clienteCOMPRA = null;
    private funcionario funcionarioCOMPRA = null;
    private List<carro> TEMPCARROLIST = new ArrayList<>();
    private List<moto> TEMPMOTOLIST = new ArrayList<>();
    private List<produto> TEMPPRODUTOLIST = new ArrayList<>();
    private List<servico> TEMPSERVICOLIST = new ArrayList<>();

    public void insertVender(dataBase banco, int id) {
        //acha index da lista local
        int indexCompra = 0;
        int indexCarro = 0;
        int indexMoto = 0;
        int indexProduto = 0;
        int indexServico = 0;

        for (int i = 0; i < banco.getCompraList().size(); i++) {

            if (banco.getCompraList().get(i).getId() == id) {
                indexCompra = i;
                break;
            }
        }

        //COMPRA
        try {
            query = "insert into compra (id) values (?)";
            pst = conect.prepareStatement(query);
            pst.setInt(1, id);

            pst.executeUpdate();
            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de compra");
        }

        //defini 1 ou 0 para opcao booleanas
        String sexoFuncionario = "0", turno = "0", sexoCliente = "0", ar = "0", quatro = "0";

        if (banco.getCompraList()
                .get(indexCompra).getFUNCIONARIO().isTurnoComercial()) {
            turno = "1";
        }

        if (banco.getCompraList()
                .get(indexCompra).getCLIENTE().isSexoMasculino()) {
            sexoCliente = "1";
        }

        //FUNCIONARIO
        try {
            query = "insert into funcionario_list (id_list, id, cpf, nome, nascimento, endereco, sexoMasculino, cnh, cargo, salario, turnoComercial) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?)";
            pst = conect.prepareStatement(query);
            pst.setInt(1, id);
            pst.setInt(2, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getId());
            pst.setString(3, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getCpf());
            pst.setString(4, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getNome());
            pst.setString(5, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getNascimento());
            pst.setString(6, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getEndereço());
            pst.setString(7, sexoFuncionario);
            pst.setString(8, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getCnh());
            pst.setString(9, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getCargo());
            pst.setString(10, banco.getCompraList().get(indexCompra).getFUNCIONARIO().getSalario());
            pst.setString(11, turno);

            pst.executeUpdate();
            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de funcionario_list");
        }

        //CLIENTE
        try {
            query = "insert into cliente_list (id_list, id, cpf, nome, nascimento, endereco, sexoMasculino, cnh, celular, email) "
                    + "values (?,?,?,?,?,?,?,?,?,?)";
            pst = conect.prepareStatement(query);
            pst.setInt(1, id);
            pst.setInt(2, banco.getCompraList().get(indexCompra).getCLIENTE().getId());
            pst.setString(3, banco.getCompraList().get(indexCompra).getCLIENTE().getCpf());
            pst.setString(4, banco.getCompraList().get(indexCompra).getCLIENTE().getNome());
            pst.setString(5, banco.getCompraList().get(indexCompra).getCLIENTE().getNascimento());
            pst.setString(6, banco.getCompraList().get(indexCompra).getCLIENTE().getEndereço());
            pst.setString(7, sexoCliente);
            pst.setString(8, banco.getCompraList().get(indexCompra).getCLIENTE().getCnh());
            pst.setString(9, banco.getCompraList().get(indexCompra).getCLIENTE().getCelular());
            pst.setString(10, banco.getCompraList().get(indexCompra).getCLIENTE().getEmail());

            pst.executeUpdate();
            pst.close();

        } catch (SQLException ex) {
            Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de cliente_list");
        }
        //CARRO LIST
        if (!banco.getCompraList().get(indexCompra).getCARROLIST().isEmpty()) {

            for (int i = 0; i < banco.getCompraList().get(indexCompra).getCARROLIST().size(); i++) {

                indexCarro = i;

                ar = "0";
                quatro = "0";

                if (banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).isArCondicionado()) {
                    ar = "1";
                }

                if (banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).isQuatroPortas()) {
                    quatro = "1";
                }

                try {
                    query = "insert into  carro_list (id_list, id, placa, marca, cor, chassi, modelo, ano, km, valor, quatroPortas, arCondicionado) "
                            + "values (?,?,?,?,?,?,?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, id);
                    pst.setInt(2, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getId());
                    pst.setString(3, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getPlaca());
                    pst.setString(4, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getMarca());
                    pst.setString(5, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getCor());
                    pst.setString(6, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getChassi());
                    pst.setString(7, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getModelo());
                    pst.setString(8, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getAno());
                    pst.setString(9, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getKm());
                    pst.setString(10, banco.getCompraList().get(indexCompra).getCARROLIST().get(indexCarro).getValor());
                    pst.setString(11, quatro);
                    pst.setString(12, ar);

                    pst.executeUpdate();
                    pst.close();

                } catch (SQLException ex) {
                    Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de carro_list");
                }
            }
        }
        //MOTO LIST
        if (!banco.getCompraList().get(indexCompra).getMOTOLIST().isEmpty()) {
            for (int i = 0; i < banco.getCompraList().get(indexCompra).getMOTOLIST().size(); i++) {

                indexMoto = i;
                if (banco.getCompraList().get(indexCompra).getFUNCIONARIO().isSexoMasculino()) {
                    sexoFuncionario = "1";
                }

                try {
                    query = "insert into moto_list (id_list, id, placa, marca, cor, chassi, modelo, ano, km, valor) "
                            + "values (?,?,?,?,?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, id);
                    pst.setInt(2, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getId());
                    pst.setString(3, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getPlaca());
                    pst.setString(4, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getMarca());
                    pst.setString(5, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getCor());
                    pst.setString(6, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getChassi());
                    pst.setString(7, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getModelo());
                    pst.setString(8, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getAno());
                    pst.setString(9, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getKm());
                    pst.setString(10, banco.getCompraList().get(indexCompra).getMOTOLIST().get(indexMoto).getValor());

                    pst.executeUpdate();
                    pst.close();

                } catch (SQLException ex) {
                    Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de moto_list");
                }
            }
        }
        //PRODUTO LIST
        if (!banco.getCompraList().get(indexCompra).getPRODUTOLIST().isEmpty()) {

            for (int i = 0; i < banco.getCompraList().get(indexCompra).getPRODUTOLIST().size(); i++) {

                indexProduto = i;

                try {
                    query = "insert into produto_list (id_list, id, valor, nome, quantidade, descricao) "
                            + "values (?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, id);
                    pst.setInt(2, banco.getCompraList().get(indexCompra).getPRODUTOLIST().get(indexProduto).getId());
                    pst.setString(3, banco.getCompraList().get(indexCompra).getPRODUTOLIST().get(indexProduto).getValor());
                    pst.setString(4, banco.getCompraList().get(indexCompra).getPRODUTOLIST().get(indexProduto).getNome());
                    pst.setInt(5, banco.getCompraList().get(indexCompra).getPRODUTOLIST().get(indexProduto).getQuantidade());
                    pst.setString(6, banco.getCompraList().get(indexCompra).getPRODUTOLIST().get(indexProduto).getDescrição());

                    pst.executeUpdate();
                    pst.close();

                } catch (SQLException ex) {
                    Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de produto_list");
                }
            }
        }
        //SERVICO LIST
        if (!banco.getCompraList().get(indexCompra).getSERVICOLIST().isEmpty()) {
            for (int i = 0; i < banco.getCompraList().get(indexCompra).getSERVICOLIST().size(); i++) {

                indexServico = i;

                try {
                    query = "insert into servico_list (id_list, id, valor, nome, descricao)"
                            + "values (?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, id);
                    pst.setInt(2, banco.getCompraList().get(indexCompra).getSERVICOLIST().get(indexServico).getId());
                    pst.setString(3, banco.getCompraList().get(indexCompra).getSERVICOLIST().get(indexServico).getValor());
                    pst.setString(4, banco.getCompraList().get(indexCompra).getSERVICOLIST().get(indexServico).getNome());
                    pst.setString(5, banco.getCompraList().get(indexCompra).getSERVICOLIST().get(indexServico).getDescrição());

                    pst.executeUpdate();
                    pst.close();

                } catch (SQLException ex) {
                    Logger.getLogger(dao.class.getName()).log(Level.SEVERE, null, ex);
                    JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de servico_list index = " + indexServico );
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Venda realizada com sucesso!");
    }

    public dataBase preencherListas(dataBase banco) {
        //carro
        try {
            query = "select * from carro";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                boolean ar = false;
                boolean quatro = false;

                if (rs.getString("arCondicionado").equals("1")) {
                    ar = true;
                }
                if (rs.getString("quatroPortas").equals("1")) {
                    quatro = true;
                }
                carro CARRO = new carro(rs.getInt("id"), rs.getString("marca"), rs.getString("placa"), rs.getString("cor"),
                        rs.getString("chassi"), rs.getString("modelo"), rs.getString("ano"), rs.getString("km"),
                        rs.getString("valor"), quatro, ar);

                banco.getCarroList().add(CARRO);
                banco.setId_carro(rs.getInt("id") + 1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de carro");
        }
        //moto
        try {
            query = "select * from moto";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                moto MOTO = new moto(rs.getInt("id"), rs.getString("marca"), rs.getString("placa"), rs.getString("cor"),
                        rs.getString("chassi"), rs.getString("modelo"), rs.getString("ano"), rs.getString("km"),
                        rs.getString("valor"));

                banco.getMotoList().add(MOTO);
                banco.setId_moto(rs.getInt("id") + 1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de moto");
        }
        //produto
        try {
            query = "select * from produto";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                produto PRODUTO = new produto(rs.getInt("id"), rs.getString("valor"), rs.getString("nome"), rs.getInt("quantidade"),
                        rs.getString("descricao"));

                banco.getProdutoList().add(PRODUTO);
                banco.setId_produto(rs.getInt("id") + 1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de produto");
        }

        //servico
        try {
            query = "select * from servico";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                servico SERVICO = new servico(rs.getInt("id"), rs.getString("valor"), rs.getString("nome"), rs.getString("descricao"));

                banco.getServicoList().add(SERVICO);
                banco.setId_servico(rs.getInt("id") + 1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de produto");
        }

        //funcionario
        try {
            query = "select * from funcionario";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                boolean sexo = false;
                boolean turno = false;

                if (rs.getString("sexoMasculino").equals("1")) {
                    sexo = true;
                }
                if (rs.getString("turnoComercial").equals("1")) {
                    turno = true;
                }

                funcionario FUNCIONARIO = new funcionario(rs.getInt("id"), rs.getString("cpf"), rs.getString("nome"), rs.getString("endereco"),
                        rs.getString("nascimento"), sexo, rs.getString("cnh"), rs.getString("cargo"), rs.getString("salario"),
                        turno);

                banco.getFuncionarioList().add(FUNCIONARIO);
                banco.setId_funcionario(rs.getInt("id") + 1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de funcionario");
        }

        //cliente
        try {
            query = "select * from cliente";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                boolean SEXO = false;

                if (rs.getString("sexoMasculino").equals("1")) {
                    SEXO = true;
                }

                cliente CLIENTE = new cliente(rs.getInt("id"), rs.getString("cpf"), rs.getString("nome"), rs.getString("endereco"),
                        rs.getString("nascimento"), SEXO, rs.getString("cnh"), rs.getString("celular"), rs.getString("email"));

                banco.getClienteList().add(CLIENTE);
                banco.setId_cliente(rs.getInt("id") + 1);

            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de funcionario");
        }

        //contador de compras
        try {
            query = "select * from compra";
            st = conect.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                banco.setId_compra(rs.getInt("id") + 1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de compra");
        }

        for (int i = 1; i < banco.getId_compra(); i++) {

            //cliente
            boolean sexoCliente = false;
            try {
                query = "select * from cliente_list where id_list = " + i;
                st = conect.createStatement();
                rs = st.executeQuery(query);
                while (rs.next()) {

                    if (rs.getString("sexoMasculino").equals("1")) {
                        sexoCliente = true;
                    }
                        cliente clienteCompra = new cliente(rs.getInt("id"), rs.getString("cpf"), rs.getString("nome"), rs.getString("nascimento"),
                                rs.getString("endereco"), sexoCliente, rs.getString("cnh"), rs.getString("celular"), rs.getString("email"));
                        clienteCOMPRA = clienteCompra;
                    }
            } catch (SQLException ex) {
                Logger.getLogger(dao.class
                        .getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de cliente list");
            }

            //funcionario
            boolean sexoFuncionario = false;
            boolean turno = false;
            try {
                query = "select * from funcionario_list where id_list = " + i;
                st = conect.createStatement();
                rs = st.executeQuery(query);
                while (rs.next()) {

                    if (rs.getString("sexoMasculino").equals("1")) {
                        sexoFuncionario = true;
                    }
                        if (rs.getString("turnoComercial").equals("1")) {
                            turno = true;
                        }

                        funcionario funcionarioCompra = new funcionario(rs.getInt("id"), rs.getString("cpf"), rs.getString("nome"), rs.getString("nascimento"),
                                rs.getString("endereco"), sexoFuncionario, rs.getString("cnh"), rs.getString("cargo"), rs.getString("salario"), turno);
                        funcionarioCOMPRA = funcionarioCompra;
                    
                }
            } catch (SQLException ex) {
                Logger.getLogger(dao.class
                        .getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de funcionario list");
            }

            //lista de carro
            try {
                query = "select * from carro_list where id_list = " + i;
                st = conect.createStatement();
                rs = st.executeQuery(query);
                while (rs != null && rs.next()) {

                    boolean ar = false, quatro = false;

                    if (rs.getString("arCondicionado").equals("1")) {
                        ar = true;
                    }
                    if (rs.getString("quatroPortas").equals("1")) {
                        quatro = true;
                    }

                    carro carroCompra = new carro(rs.getInt("id"), rs.getString("placa"), rs.getString("marca"), rs.getString("cor"),
                            rs.getString("chassi"), rs.getString("modelo"), rs.getString("ano"), rs.getString("km"),
                            rs.getString("valor"), quatro, ar);
                    TEMPCARROLIST.add(carroCompra);
                }

            } catch (SQLException ex) {
                Logger.getLogger(dao.class
                        .getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de carro list");
            }
            //lista de moto
            try {
                query = "select * from moto_list where id_list = " + i;
                st = conect.createStatement();
                rs = st.executeQuery(query);
                while (rs != null && rs.next()) {

                    moto motoCompra = new moto(rs.getInt("id"), rs.getString("placa"), rs.getString("marca"), rs.getString("cor"),
                            rs.getString("chassi"), rs.getString("modelo"), rs.getString("ano"), rs.getString("km"),
                            rs.getString("valor"));
                    TEMPMOTOLIST.add(motoCompra);
                }

            } catch (SQLException ex) {
                Logger.getLogger(dao.class
                        .getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de moto list");
            }

            //lista de produto
            try {
                query = "select * from produto_list where id_list = " + i;
                st = conect.createStatement();
                rs = st.executeQuery(query);
                while (rs != null && rs.next()) {

                    produto produtoCompra = new produto(rs.getInt("id"), rs.getString("valor"), rs.getString("nome"), rs.getInt("quantidade"),
                            rs.getString("descricao"));
                    TEMPPRODUTOLIST.add(produtoCompra);
                }

            } catch (SQLException ex) {
                Logger.getLogger(dao.class
                        .getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de produto list");
            }

            //lista de servico
            try {
                query = "select * from servico_list where id_list = " + i;
                st = conect.createStatement();
                rs = st.executeQuery(query);
                while (rs != null && rs.next()) {

                    servico servicoCompra = new servico(rs.getInt("id"), rs.getString("valor"), rs.getString("nome"), rs.getString("descricao"));
                    TEMPSERVICOLIST.add(servicoCompra);
                }

            } catch (SQLException ex) {
                Logger.getLogger(dao.class
                        .getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de servico list");
            }

            //compra
            compra COMPRA = new compra(i, clienteCOMPRA, funcionarioCOMPRA, TEMPSERVICOLIST, TEMPPRODUTOLIST, TEMPCARROLIST, TEMPMOTOLIST);
            banco.getCompraList().add(COMPRA);
            clienteCOMPRA = null;
            funcionarioCOMPRA = null;
            TEMPSERVICOLIST.clear();
            TEMPPRODUTOLIST.clear();
            TEMPCARROLIST.clear();
            TEMPMOTOLIST.clear();
        }
        return banco;
    }

    public void updateBanco(dataBase banco, String tabela, int id) {
        try {
            int index = 0;
            switch (tabela) {
                case "carro":
                    for (int i = 0; i < banco.getCarroList().size(); i++) {
                        if (banco.getCarroList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    String ar = "0",
                     quatro = "0";

                    if (banco.getCarroList().get(index).isArCondicionado()) {
                        ar = "1";
                    }
                    if (banco.getCarroList().get(index).isQuatroPortas()) {
                        quatro = "1";
                    }

                    query = "update " + tabela + " set placa = ?, marca = ?, cor = ?, modelo = ?, ano = ?, km = ?, valor = ?, "
                            + "quatroPortas = ?, arCondicionado = ? where id = " + id;
                    pst = conect.prepareStatement(query);
                    pst.setString(1, banco.getCarroList().get(index).getPlaca());
                    pst.setString(2, banco.getCarroList().get(index).getMarca());
                    pst.setString(3, banco.getCarroList().get(index).getCor());
                    pst.setString(4, banco.getCarroList().get(index).getModelo());
                    pst.setString(5, banco.getCarroList().get(index).getAno());
                    pst.setString(6, banco.getCarroList().get(index).getKm());
                    pst.setString(7, banco.getCarroList().get(index).getValor());
                    pst.setString(8, quatro);
                    pst.setString(9, ar);
                    break;

                case "moto":
                    for (int i = 0; i < banco.getMotoList().size(); i++) {
                        if (banco.getMotoList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    query = "update " + tabela + " set placa = ?, marca = ?, cor = ?, modelo = ?, ano = ?, km = ?, valor = ? where id = " + id;
                    pst = conect.prepareStatement(query);
                    pst.setString(1, banco.getMotoList().get(index).getPlaca());
                    pst.setString(2, banco.getMotoList().get(index).getMarca());
                    pst.setString(3, banco.getMotoList().get(index).getCor());
                    pst.setString(4, banco.getMotoList().get(index).getModelo());
                    pst.setString(5, banco.getMotoList().get(index).getAno());
                    pst.setString(6, banco.getMotoList().get(index).getKm());
                    pst.setString(7, banco.getMotoList().get(index).getValor());
                    break;

                case "cliente":
                    for (int i = 0; i < banco.getClienteList().size(); i++) {
                        if (banco.getClienteList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    String masculino = "0";

                    if (banco.getClienteList().get(index).isSexoMasculino()) {
                        masculino = "1";
                    }
                    query = "update " + tabela + " set cpf = ?, nome = ?, nascimento = ?, endereco = ?, sexoMasculino = ?, cnh = ?, celular = ?, "
                            + "email = ? where id = " + id;
                    pst = conect.prepareStatement(query);
                    pst.setString(1, banco.getClienteList().get(index).getCpf());
                    pst.setString(2, banco.getClienteList().get(index).getNome());
                    pst.setString(3, banco.getClienteList().get(index).getNascimento());
                    pst.setString(4, banco.getClienteList().get(index).getEndereço());
                    pst.setString(5, masculino);
                    pst.setString(6, banco.getClienteList().get(index).getCnh());
                    pst.setString(7, banco.getClienteList().get(index).getCelular());
                    pst.setString(8, banco.getClienteList().get(index).getEmail());
                    break;

                case "funcionario":
                    for (int i = 0; i < banco.getFuncionarioList().size(); i++) {
                        if (banco.getFuncionarioList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    String MASCULINO = "0",
                     turno = "0";

                    if (banco.getFuncionarioList().get(index).isSexoMasculino()) {
                        MASCULINO = "1";
                    }

                    if (banco.getFuncionarioList().get(index).isTurnoComercial()) {
                        turno = "1";
                    }

                    query = "update " + tabela + " set cpf = ?, nome = ?, nascimento = ?, endereco = ?, sexoMasculino = ?, cnh = ?, cargo = ?, "
                            + "salario = ?, turnoComercial = ? where id = " + id;
                    pst = conect.prepareStatement(query);
                    pst.setString(1, banco.getFuncionarioList().get(index).getCpf());
                    pst.setString(2, banco.getFuncionarioList().get(index).getNome());
                    pst.setString(3, banco.getFuncionarioList().get(index).getNascimento());
                    pst.setString(4, banco.getFuncionarioList().get(index).getEndereço());
                    pst.setString(5, MASCULINO);
                    pst.setString(6, banco.getFuncionarioList().get(index).getCnh());
                    pst.setString(7, banco.getFuncionarioList().get(index).getCargo());
                    pst.setString(8, banco.getFuncionarioList().get(index).getSalario());
                    pst.setString(9, turno);
                    break;

                case "produto":
                    for (int i = 0; i < banco.getProdutoList().size(); i++) {
                        if (banco.getProdutoList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    query = "update " + tabela + " set valor = ?, nome = ?, quantidade = ?, descricao = ? where id = " + id;
                    pst = conect.prepareStatement(query);
                    pst.setString(1, banco.getProdutoList().get(index).getValor());
                    pst.setString(2, banco.getProdutoList().get(index).getNome());
                    pst.setString(3, "" + banco.getProdutoList().get(index).getQuantidade());
                    pst.setString(4, banco.getProdutoList().get(index).getDescrição());
                    break;

                case "servico":
                    for (int i = 0; i < banco.getServicoList().size(); i++) {
                        if (banco.getServicoList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    query = "update " + tabela + " set valor = ?, nome = ?, descricao = ? where id = " + id;
                    pst = conect.prepareStatement(query);
                    pst.setString(1, banco.getServicoList().get(index).getValor());
                    pst.setString(2, banco.getServicoList().get(index).getNome());
                    pst.setString(3, banco.getServicoList().get(index).getDescrição());
                    break;

                default:
                    throw new AssertionError();
            }
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de carro");
        }
    }

    public void insertBanco(dataBase banco, String tabela, int id) {

        try {
            int index = 0;
            switch (tabela) {
                case "carro":
                    for (int i = 0; i < banco.getCarroList().size(); i++) {
                        if (banco.getCarroList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    String ar = "0",
                     quatro = "0";

                    if (banco.getCarroList().get(index).isArCondicionado()) {
                        ar = "1";
                    }
                    if (banco.getCarroList().get(index).isQuatroPortas()) {
                        quatro = "1";
                    }

                    query = "insert into " + tabela + " (id, placa, marca, cor, chassi, modelo, ano, km, valor, quatroPortas, arCondicionado) "
                            + "values (?,?,?,?,?,?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, id);
                    pst.setString(2, banco.getCarroList().get(index).getPlaca());
                    pst.setString(3, banco.getCarroList().get(index).getMarca());
                    pst.setString(4, banco.getCarroList().get(index).getCor());
                    pst.setString(5, banco.getCarroList().get(index).getChassi());
                    pst.setString(6, banco.getCarroList().get(index).getModelo());
                    pst.setString(7, banco.getCarroList().get(index).getAno());
                    pst.setString(8, banco.getCarroList().get(index).getKm());
                    pst.setString(9, banco.getCarroList().get(index).getValor());
                    pst.setString(10, quatro);
                    pst.setString(11, ar);
                    JOptionPane.showMessageDialog(null, "Carro inserido com sucesso!");
                    break;

                case "moto":
                    for (int i = 0; i < banco.getMotoList().size(); i++) {
                        if (banco.getMotoList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    query = "insert into " + tabela + " (id, placa, marca, cor, chassi, modelo, ano, km, valor) "
                            + "values (?,?,?,?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, id);
                    pst.setString(2, banco.getMotoList().get(index).getPlaca());
                    pst.setString(3, banco.getMotoList().get(index).getMarca());
                    pst.setString(4, banco.getMotoList().get(index).getCor());
                    pst.setString(5, banco.getMotoList().get(index).getChassi());
                    pst.setString(6, banco.getMotoList().get(index).getModelo());
                    pst.setString(7, banco.getMotoList().get(index).getAno());
                    pst.setString(8, banco.getMotoList().get(index).getKm());
                    pst.setString(9, banco.getMotoList().get(index).getValor());
                    JOptionPane.showMessageDialog(null, "Moto inserida com sucesso!");
                    break;

                case "cliente":
                    for (int i = 0; i < banco.getClienteList().size(); i++) {
                        if (banco.getClienteList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    String masculino = "0";

                    if (banco.getClienteList().get(index).isSexoMasculino()) {
                        masculino = "1";
                    }
                    query = "insert into " + tabela + " (id, cpf, nome, nascimento, endereco, sexoMasculino, cnh, celular, email) "
                            + "values (?,?,?,?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, banco.getClienteList().get(index).getId());
                    pst.setString(2, banco.getClienteList().get(index).getCpf());
                    pst.setString(3, banco.getClienteList().get(index).getNome());
                    pst.setString(4, banco.getClienteList().get(index).getNascimento());
                    pst.setString(5, banco.getClienteList().get(index).getEndereço());
                    pst.setString(6, masculino);
                    pst.setString(7, banco.getClienteList().get(index).getCnh());
                    pst.setString(8, banco.getClienteList().get(index).getCelular());
                    pst.setString(9, banco.getClienteList().get(index).getEmail());
                    JOptionPane.showMessageDialog(null, "Cliente inserido com sucesso!");
                    break;

                case "funcionario":
                    for (int i = 0; i < banco.getFuncionarioList().size(); i++) {
                        if (banco.getFuncionarioList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    String MASCULINO = "0",
                     turno = "0";

                    if (banco.getFuncionarioList().get(index).isSexoMasculino()) {
                        MASCULINO = "1";
                    }

                    if (banco.getFuncionarioList().get(index).isTurnoComercial()) {
                        turno = "1";
                    }

                    query = "insert into " + tabela + " (id, cpf, nome, nascimento, endereco, sexoMasculino, cnh, cargo, salario, turnoComercial) "
                            + "values (?,?,?,?,?,?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, banco.getFuncionarioList().get(index).getId());
                    pst.setString(2, banco.getFuncionarioList().get(index).getCpf());
                    pst.setString(3, banco.getFuncionarioList().get(index).getNome());
                    pst.setString(4, banco.getFuncionarioList().get(index).getNascimento());
                    pst.setString(5, banco.getFuncionarioList().get(index).getEndereço());
                    pst.setString(6, MASCULINO);
                    pst.setString(7, banco.getFuncionarioList().get(index).getCnh());
                    pst.setString(8, banco.getFuncionarioList().get(index).getCargo());
                    pst.setString(9, banco.getFuncionarioList().get(index).getSalario());
                    pst.setString(10, turno);
                    JOptionPane.showMessageDialog(null, "Funcionario inserido com sucesso!");
                    break;

                case "produto":
                    for (int i = 0; i < banco.getProdutoList().size(); i++) {
                        if (banco.getProdutoList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    query = "insert into " + tabela + " (id, valor, nome, quantidade, descricao) "
                            + "values (?,?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, banco.getProdutoList().get(index).getId());
                    pst.setString(2, banco.getProdutoList().get(index).getValor());
                    pst.setString(3, banco.getProdutoList().get(index).getNome());
                    pst.setInt(4, banco.getProdutoList().get(index).getQuantidade());
                    pst.setString(5, banco.getProdutoList().get(index).getDescrição());
                    JOptionPane.showMessageDialog(null, "Produto inserido com sucesso!");
                    break;

                case "servico":
                    for (int i = 0; i < banco.getServicoList().size(); i++) {
                        if (banco.getServicoList().get(i).getId() == id) {
                            index = i;
                            break;
                        }
                    }

                    query = "insert into " + tabela + " (id, valor, nome, descricao)"
                            + "values (?,?,?,?)";
                    pst = conect.prepareStatement(query);
                    pst.setInt(1, banco.getServicoList().get(index).getId());
                    pst.setString(2, banco.getServicoList().get(index).getValor());
                    pst.setString(3, banco.getServicoList().get(index).getNome());
                    pst.setString(4, banco.getServicoList().get(index).getDescrição());
                    JOptionPane.showMessageDialog(null, "Serviço inserido com sucesso!");
                    break;

                default:
                    throw new AssertionError();
            }
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela");
        }
    }

    public void deleteBanco(dataBase banco, String tabela, int id) {

        try {
            query = "delete from " + tabela + " where id = " + id;
            pst = conect.prepareStatement(query);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "" + tabela + " excluido com sucesso!");
            
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela");
        }
        try {
            query = "select * from " + tabela;
            st = conect.createStatement();
            rs = st.executeQuery(query);

            switch (tabela) {
                case "compra":
                    banco.setId_compra(1);
                    break;

                case "cliente":
                    banco.setId_cliente(1);
                    break;

                case "funcionario":
                    banco.setId_funcionario(1);
                    break;

                case "moto":
                    banco.setId_moto(1);
                    break;

                case "carro":
                    banco.setId_carro(1);
                    break;

                case "produto":
                    banco.setId_produto(1);
                    break;

                case "servico":
                    banco.setId_servico(1);
                    break;

                default:
                    throw new AssertionError();
            }

            while (rs.next()) {
                switch (tabela) {
                    case "compra":
                        banco.setId_compra(rs.getInt("id") + 1);
                        break;

                    case "cliente":
                        banco.setId_cliente(rs.getInt("id") + 1);
                        break;

                    case "funcionario":
                        banco.setId_funcionario(rs.getInt("id") + 1);
                        break;

                    case "moto":
                        banco.setId_moto(rs.getInt("id") + 1);
                        break;

                    case "carro":
                        banco.setId_carro(rs.getInt("id") + 1);
                        break;

                    case "produto":
                        banco.setId_produto(rs.getInt("id") + 1);
                        break;

                    case "servico":
                        banco.setId_servico(rs.getInt("id") + 1);
                        break;

                    default:
                        throw new AssertionError();
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(dao.class
                    .getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a tabela de " + tabela);
        }
    }
}