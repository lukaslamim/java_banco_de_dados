
package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
/**
 *
 * @author utirra
 */
public class conectionDB {   
    
    public static Connection FazerConeccao()
    {
        Connection conectar = null;
    
        String USER = "root";
        String PASS = "";
        String URL = "jdbc:mysql://localhost:3306/osmar"; 
        
        try{
             conectar = DriverManager.getConnection(URL, USER, PASS);
        }
        
        catch(Exception e)
        {
            conectar = null;
            JOptionPane.showMessageDialog(null, "erro ao conectar com o banco de dados" + e.toString());
        }
        return conectar;
    }
    
    
}
