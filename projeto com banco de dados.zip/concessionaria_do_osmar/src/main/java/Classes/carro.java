/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author lucaslamim-fit
 */
public class carro extends veiculo {
 
    private boolean quatroPortas = true;
    private boolean arCondicionado = false;
    
    public carro(int id, String marca, String placa, String cor, String chassi, String modelo, String ano,
    String km, String valor, boolean quatroPortas, boolean arCondicionado)
    {
       super(id, marca, placa, cor, chassi, modelo, ano, km, valor);
       this.quatroPortas = quatroPortas;
       this.arCondicionado = arCondicionado;
    }  
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @return the cor
     */
    public String getCor() {
        return cor;
    }

    /**
     * @return the chassi
     */
    public String getChassi() {
        return chassi;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    } 
    /**
     * @return the ano
     */
    public String getAno() {
        return ano;
    }

    /**
     * @return the km
     */
    public String getKm() {
        return km;
    }

    /**
     * @return the quatroPortas
     */
    public boolean isQuatroPortas() {
        return quatroPortas;
    }

    /**
     * @return the arCondicionado
     */
    public boolean isArCondicionado() {
        return arCondicionado;
    }
        /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }
}

