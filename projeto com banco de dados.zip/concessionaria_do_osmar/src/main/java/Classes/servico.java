
package Classes;
/**
 *
 * @author lucaslamim-fit
 */
public class servico {
    
    private int id = 0;
    private String valor = "";
    private String nome = "";
    private String descricao = "";  

    public servico(int id, String valor,String nome, String descrição) 
    {
        this.id = id;
        this.valor = valor;
        this.nome = nome;
        this.descricao = descrição;     
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the descrição
     */
    public String getDescrição() {
        return descricao;
    }   
}
