/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author lucaslamim-fit
 */
public abstract class pessoa {
    
    protected int id = 0;
    protected String cpf = "";
    protected String nome = "";
    protected String nascimento = "";
    protected String endereço = "";
    protected boolean sexoMasculino = true;
    protected String cnh = "";
    
    public pessoa(int id, String cpf, String nome, String nascimento, String endereço, boolean sexoMasculino, String cnh)
    {
        this.id = id;
        this.cpf = cpf;
        this.nome = nome;
        this.nascimento = nascimento;
        this.endereço = endereço;
        this.sexoMasculino = sexoMasculino;
        this.cnh = cnh;
    }
}
