/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author lucaslamim-fit
 */
public class compra {
   
       private int id = 0;
       private cliente CLIENTE;
       private funcionario FUNCIONARIO;
       private List<carro> CARROLIST = new ArrayList<>();
       private List<moto> MOTOLIST = new ArrayList<>();
       private List<produto> PRODUTOLIST = new ArrayList<>();
       private List<servico> SERVICOLIST = new ArrayList<>();
       
       public compra(int id, cliente CLIENTE, funcionario FUNCIONARIO, List<servico> SERVICO, List<produto> PRODUTO, List<carro> CARRO,
       List<moto> MOTO)
       {
           this.id = id;
           this.CLIENTE = CLIENTE;
           this.FUNCIONARIO = FUNCIONARIO;
           for(int i = 0; i < CARRO.size(); i++)
           {
               this.CARROLIST.add(CARRO.get(i));
           }
           for(int i = 0; i < MOTO.size(); i++)
           {
               this.MOTOLIST.add(MOTO.get(i));
           }
           for(int i = 0; i < SERVICO.size(); i++)
           {
               this.SERVICOLIST.add(SERVICO.get(i));
           }
           for(int i = 0; i < PRODUTO.size(); i++)
           {
               this.PRODUTOLIST.add(PRODUTO.get(i));
           }
       }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the CLIENTE
     */
    public cliente getCLIENTE() {
        return CLIENTE;
    }

    /**
     * @return the FUNCIONARIO
     */
    public funcionario getFUNCIONARIO() {
        return FUNCIONARIO;
    }

    /**
     * @return the CARROLIST
     */
    public List<carro> getCARROLIST() {
        return CARROLIST;
    }

    /**
     * @return the MOTOLIST
     */
    public List<moto> getMOTOLIST() {
        return MOTOLIST;
    }

    /**
     * @return the PRODUTOLIST
     */
    public List<produto> getPRODUTOLIST() {
        return PRODUTOLIST;
    }

    /**
     * @return the SERVICOLIST
     */
    public List<servico> getSERVICOLIST() {
        return SERVICOLIST;
    }
}
