/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author lucaslamim-fit
 */
public abstract class veiculo {
    
    protected int id = 0;
    protected String marca = "";
    protected String placa = "";
    protected String cor = "";
    protected String chassi = "";
    protected String modelo = "";
    protected String ano = "";
    protected String km = "";
    protected String valor = "";
    
    public veiculo(int id, String marca, String placa, String cor, String chassi, String modelo, String ano, String km, String valor)
    {
        this.id = id;
        this.marca = marca;
        this.placa = placa;
        this.cor = cor;
        this.chassi = chassi;
        this.modelo = modelo;
        this.ano = ano;
        this.km = km;
        this.valor = valor;
    }
}

