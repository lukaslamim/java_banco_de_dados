/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author lucaslamim-fit
 */
public class funcionario extends pessoa {
    
    private String cargo = "";
    private String salario = "";
    private boolean turnoComercial = true;
    
    public funcionario(int id, String cpf, String nome, String nascimento, String endereço, boolean sexoMasculino, String cnh, String cargo, String salario, boolean turnoComercial)
    {
       super(id, cpf, nome, nascimento, endereço, sexoMasculino, cnh);
       this.cargo = cargo;
       this.salario = salario;
       this.turnoComercial = turnoComercial;
    }  

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the nascimento
     */
    public String getNascimento() {
        return nascimento;
    }

    /**
     * @return the endereço
     */
    public String getEndereço() {
        return endereço;
    }

    /**
     * @return the sexoMasculino
     */
    public boolean isSexoMasculino() {
        return sexoMasculino;
    }

    /**
     * @return the cnh
     */
    public String getCnh() {
        return cnh;
    }  

    /**
     * @return the cargo
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * @return the salario
     */
    public String getSalario() {
        return salario;
    }

    /**
     * @return the turnoComercial
     */
    public boolean isTurnoComercial() {
        return turnoComercial;
    }
}
