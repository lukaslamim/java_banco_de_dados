-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 06-Jul-2022 às 13:56
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `osmar`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `carro`
--

CREATE TABLE `carro` (
  `id` int(11) NOT NULL,
  `placa` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `marca` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `cor` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `chassi` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `modelo` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `ano` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `km` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `valor` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `quatroPortas` varchar(1) COLLATE utf8_bin DEFAULT NULL,
  `arCondicionado` varchar(1) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `carro`
--

INSERT INTO `carro` (`id`, `placa`, `marca`, `cor`, `chassi`, `modelo`, `ano`, `km`, `valor`, `quatroPortas`, `arCondicionado`) VALUES
(1, 'teste', 'teste', 'teste', 'teste', 'teste', 'teste', 'testeteste', 'teste', '1', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `carro_list`
--

CREATE TABLE `carro_list` (
  `id` int(11) DEFAULT NULL,
  `placa` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `marca` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `cor` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `chassi` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ano` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `km` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `valor` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `quatroPortas` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `arCondicionado` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `id_list` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `cpf` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `nome` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `nascimento` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `endereco` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `sexoMasculino` varchar(1) CHARACTER SET utf8mb4 DEFAULT NULL,
  `cnh` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `celular` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `email` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`id`, `cpf`, `nome`, `nascimento`, `endereco`, `sexoMasculino`, `cnh`, `celular`, `email`) VALUES
(1, '12345678910', 'lukas', '05/11/2001', 'nao eh da sua conta', '0', '', '', ''),
(2, '666', 'satan', '06/06/66', 'inferno', '1', '', '', 'cavalodetroia@msn.com.br'),
(3, 'teste', 'teste', 'teste', 'teste', '1', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_list`
--

CREATE TABLE `cliente_list` (
  `id` int(11) DEFAULT NULL,
  `cpf` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `nome` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `nascimento` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `endereco` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `sexoMasculino` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `cnh` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `celular` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `email` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `id_list` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cliente_list`
--

INSERT INTO `cliente_list` (`id`, `cpf`, `nome`, `nascimento`, `endereco`, `sexoMasculino`, `cnh`, `celular`, `email`, `id_list`) VALUES
(2, '666', 'satan', 'inferno', '06/06/66', '1', '', '', 'cavalodetroia@msn.com.br', 1),
(2, '666', 'satan', 'inferno', '06/06/66', '1', '', '', 'cavalodetroia@msn.com.br', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `compra`
--

CREATE TABLE `compra` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `compra`
--

INSERT INTO `compra` (`id`) VALUES
(1),
(2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `id` int(11) NOT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `sexoMasculino` varchar(45) DEFAULT NULL,
  `cnh` varchar(45) DEFAULT NULL,
  `cargo` varchar(45) DEFAULT NULL,
  `salario` varchar(45) DEFAULT NULL,
  `turnoComercial` varchar(1) DEFAULT NULL,
  `nascimento` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`id`, `cpf`, `nome`, `endereco`, `sexoMasculino`, `cnh`, `cargo`, `salario`, `turnoComercial`, `nascimento`) VALUES
(2, '12345679999', 'alex', '14/12/1977', '1', 'A e B', 'mestre de todos', '1500000', '0', 'rua corno da silva'),
(4, 'teste', 'testeedit', 'teste', '1', 'teste', 'teste', 'teste', '1', 'teste');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario_list`
--

CREATE TABLE `funcionario_list` (
  `id` int(11) DEFAULT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `sexoMasculino` varchar(45) DEFAULT NULL,
  `cnh` varchar(45) DEFAULT NULL,
  `salario` varchar(45) DEFAULT NULL,
  `turnoComercial` varchar(45) DEFAULT NULL,
  `nascimento` varchar(45) DEFAULT NULL,
  `id_list` int(11) DEFAULT NULL,
  `cargo` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `funcionario_list`
--

INSERT INTO `funcionario_list` (`id`, `cpf`, `nome`, `endereco`, `sexoMasculino`, `cnh`, `salario`, `turnoComercial`, `nascimento`, `id_list`, `cargo`) VALUES
(2, '12345679999', 'alex', 'rua corno da silva', '0', 'A e B', '1500000', '0', '14/12/1977', 1, 'mestre de todos'),
(2, '12345679999', 'alex', 'rua corno da silva', '0', 'A e B', '1500000', '0', '14/12/1977', 2, 'mestre de todos');

-- --------------------------------------------------------

--
-- Estrutura da tabela `moto`
--

CREATE TABLE `moto` (
  `id` int(11) NOT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `placa` varchar(45) DEFAULT NULL,
  `cor` varchar(45) DEFAULT NULL,
  `chassi` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) DEFAULT NULL,
  `ano` varchar(45) DEFAULT NULL,
  `km` varchar(45) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `moto`
--

INSERT INTO `moto` (`id`, `marca`, `placa`, `cor`, `chassi`, `modelo`, `ano`, `km`, `valor`) VALUES
(1, 'yamaha', 'teste edit', 'nao binario', '1545487', 'titan', '2022', '15478', '4154');

-- --------------------------------------------------------

--
-- Estrutura da tabela `moto_list`
--

CREATE TABLE `moto_list` (
  `id` int(11) DEFAULT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `placa` varchar(45) DEFAULT NULL,
  `cor` varchar(45) DEFAULT NULL,
  `chassi` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) DEFAULT NULL,
  `ano` varchar(45) DEFAULT NULL,
  `km` varchar(45) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `id_list` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `id` int(11) NOT NULL,
  `valor` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `nome` varchar(45) CHARACTER SET utf8mb4 DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `descricao` varchar(60) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `valor`, `nome`, `quantidade`, `descricao`) VALUES
(1, '10', 'escova de dente', 16, 'escova o pe');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto_list`
--

CREATE TABLE `produto_list` (
  `id` int(11) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `id_list` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produto_list`
--

INSERT INTO `produto_list` (`id`, `valor`, `nome`, `quantidade`, `descricao`, `id_list`) VALUES
(1, '10', 'escova de dente', 18, 'escova o pe', 1),
(1, '10', 'escova de dente', 17, 'escova o pe', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--

CREATE TABLE `servico` (
  `id` int(11) NOT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `servico`
--

INSERT INTO `servico` (`id`, `valor`, `nome`, `descricao`) VALUES
(1, '155', 'lichar as unha', 'licha tudo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico_list`
--

CREATE TABLE `servico_list` (
  `id` int(11) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `id_list` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `servico_list`
--

INSERT INTO `servico_list` (`id`, `valor`, `nome`, `descricao`, `id_list`) VALUES
(1, '155', 'lichar as unha', 'licha tudo', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `carro`
--
ALTER TABLE `carro`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `moto`
--
ALTER TABLE `moto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `servico`
--
ALTER TABLE `servico`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
