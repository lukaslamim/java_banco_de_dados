/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBase;

import java.util.ArrayList;
import java.util.List;
import Classes.carro;
import Classes.moto;
import Classes.cliente;
import Classes.funcionario;
import Classes.produto;
import Classes.servico;
import Classes.compra;
/**
 *
 * @author lucaslamim-fit
 */
public class dataBase {
       
    private int id_carro = 1;
    private int id_moto = 1;
    private int id_cliente = 1;
    private int id_funcionario = 1;
    private int id_produto = 1;
    private int id_servico = 1;
    private int id_compra = 1;
    
    private List<carro> carroList = new ArrayList<>();
    private List<moto> motoList = new ArrayList<>();
    private List<cliente> clienteList = new ArrayList<>();
    private List<funcionario> funcionarioList = new ArrayList<>();
    private List<produto> produtoList = new ArrayList<>();
    private List<servico> servicoList = new ArrayList<>();
    private List<compra> compraList = new ArrayList<>();
    
    
    public void inserir_carro(carro Carro) 
    {
        getCarroList().add(Carro);
        id_carro++;
    }
     
    public void inserir_moto(moto Moto) 
    {
        getMotoList().add(Moto);
        id_moto++;
    }
          
    public void inserir_cliente(cliente Cliente) 
    {
        getClienteList().add(Cliente);
        id_cliente++;
    }

    public void inserir_funcionario(funcionario Funcionario) 
    {
        getFuncionarioList().add(Funcionario);
        id_funcionario++;
    }

    public void inserir_produto(produto Produto) 
    {
        getProdutoList().add(Produto);
        id_produto++;
    }

    public void inserir_servico(servico Servico) 
    {
        getServicoList().add(Servico);
        id_servico++;
    }

    public void inserir_compra(compra Compra) 
    {
        getCompraList().add(Compra);
        id_compra++;
    }
//#######remover#######
    public void remover_carro(int id) 
    {
        if (!getCarroList().isEmpty()) 
        {
            for (int i = 0; i < getCarroList().size(); i++) 
            {
                if (getCarroList().get(i).getId() == id) 
                {
                    getCarroList().remove(i);
                }
            }
        } 
   }

    public void remover_moto(int id) 
    {
        if (!getMotoList().isEmpty()) 
        {
            for (int i = 0; i < getMotoList().size(); i++) 
            {
                if (getMotoList().get(i).getId() == id) 
                {
                    getMotoList().remove(i);
                }
            }
        }  
    }

    public void remover_cliente(int id) 
    {
        if (!getClienteList().isEmpty()) 
        {
            for (int i = 0; i < getClienteList().size(); i++) 
            {
                if (getClienteList().get(i).getId() == id) 
                {
                    getClienteList().remove(i);
                }
            }
        }    
    }

    public void remover_funcionario(int id) 
    {
        if (!getFuncionarioList().isEmpty()) 
        {
            for (int i = 0; i < getFuncionarioList().size(); i++) 
            {
                if (getFuncionarioList().get(i).getId() == id) 
                {
                    getFuncionarioList().remove(i);
                }
            }
        } 
    }

    public void remover_produto(int id) 
    {
        if (!getProdutoList().isEmpty()) 
        {
            for (int i = 0; i < getProdutoList().size(); i++) 
            {
                if (getProdutoList().get(i).getId() == id) 
                {
                    getProdutoList().remove(i);
                }
            }
        }  
    }

    public void remover_servico(int id) 
    {
        if (!getServicoList().isEmpty()) 
        {
            for (int i = 0; i < getServicoList().size(); i++) 
            {
                if (getServicoList().get(i).getId() == id) 
                {
                    getServicoList().remove(i);
                }
            }
        }  
    }

    /**
     * @return the carroList
     */
    public List<carro> getCarroList() {
        return carroList;
    }

    /**
     * @return the motoList
     */
    public List<moto> getMotoList() {
        return motoList;
    }

    /**
     * @return the clienteList
     */
    public List<cliente> getClienteList() {
        return clienteList;
    }

    /**
     * @return the funcionarioList
     */
    public List<funcionario> getFuncionarioList() {
        return funcionarioList;
    }

    /**
     * @return the produtoList
     */
    public List<produto> getProdutoList() {
        return produtoList;
    }

    /**
     * @return the servicoList
     */
    public List<servico> getServicoList() {
        return servicoList;
    }

    /**
     * @return the compraList
     */
    public List<compra> getCompraList() {
        return compraList;
    }

    /**
     * @return the id_carro
     */
    public int getId_carro() {
        return id_carro;
    }

    /**
     * @return the id_moto
     */
    public int getId_moto() {
        return id_moto;
    }

    /**
     * @return the id_cliente
     */
    public int getId_cliente() {
        return id_cliente;
    }

    /**
     * @return the id_funcionario
     */
    public int getId_funcionario() {
        return id_funcionario;
    }

    /**
     * @return the id_produto
     */
    public int getId_produto() {
        return id_produto;
    }

    /**
     * @return the id_servico
     */
    public int getId_servico() {
        return id_servico;
    
    }
    /**
     * @return the id_compra
     */
    public int getId_compra() {
        return id_compra;
    }

    /**
     * @param id_carro the id_carro to set
     */
    public void setId_carro(int id_carro) {
        this.id_carro = id_carro;
    }

    /**
     * @param id_moto the id_moto to set
     */
    public void setId_moto(int id_moto) {
        this.id_moto = id_moto;
    }

    /**
     * @param id_cliente the id_cliente to set
     */
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    /**
     * @param id_funcionario the id_funcionario to set
     */
    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    /**
     * @param id_produto the id_produto to set
     */
    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    /**
     * @param id_servico the id_servico to set
     */
    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    /**
     * @param id_compra the id_compra to set
     */
    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }
}


