
package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author utirra
 */
public class conectionDB {   
    
    public static Connection FazerConeccao()
    {
        Connection conectar = null;
    
        String USER = "root";
        String PASS = "";
        String URL = "jdbc:mysql://localhost:3306/osmar"; 
        
        try{
             conectar = DriverManager.getConnection(URL, USER, PASS);
        }
        
        catch(SQLException e)
        {
            conectar = null;
            JOptionPane.showMessageDialog(null, "erro ao estabelecer conexão com o banco de dados " + e.toString());
        }
        return conectar;
    }
    
    
}
